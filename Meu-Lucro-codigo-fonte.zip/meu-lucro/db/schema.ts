import {sqliteTable,text,integer,primaryKey} from 'drizzle-orm/sqlite-core';
export const dailyRecords=sqliteTable('daily_records',{
 userId:text('user_id').notNull(),date:text('date').notNull(),
 revenue:integer('revenue_cents').notNull(),investment:integer('investment_cents').notNull(),
 updatedAt:text('updated_at').notNull(),
},t=>[primaryKey({columns:[t.userId,t.date]})]);

import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import vm from 'node:vm';
import ts from 'typescript';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const require=createRequire(import.meta.url);
async function compile(path,module=ts.ModuleKind.ES2022){return ts.transpileModule(await readFile(new URL('../'+path,import.meta.url),'utf8'),{compilerOptions:{module,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX}}).outputText;}
async function loadModule(path){return import('data:text/javascript;base64,'+Buffer.from(await compile(path)).toString('base64'));}
const {financeRequest,FinanceApiError}=await loadModule('lib/finance-client.ts');
const finance=await loadModule('lib/finance.ts');
const originalFetch=globalThis.fetch;
try{
 let options;
 globalThis.fetch=async(_path,init)=>{options=init;return Response.json({record:{date:'2026-09-30',revenue:10000,investment:2000}});};
 assert.equal((await financeRequest('/api/records',{method:'PUT'})).record.date,'2026-09-30');
 assert.equal(options.redirect,'manual');assert.equal(options.cache,'no-store');assert.equal(options.credentials,'same-origin');assert.equal(options.headers.get('Accept'),'application/json');
 for(const response of [new Response('<!DOCTYPE html><html>Login</html>',{headers:{'Content-Type':'text/html'}}),new Response(null,{status:302,headers:{Location:'/signin-with-chatgpt'}}),Response.json({error:'Entre novamente.'},{status:401})]){
  globalThis.fetch=async()=>response;
  await assert.rejects(()=>financeRequest('/api/records'),e=>e instanceof FinanceApiError&&e.needsSignIn&&!e.message.includes('Unexpected token'));
 }
 globalThis.fetch=async()=>new Response('{', {headers:{'Content-Type':'application/json'}});
 await assert.rejects(()=>financeRequest('/api/records'),e=>!e.needsSignIn&&e.message.includes('resposta incompleta'));
 globalThis.fetch=async()=>Response.json({error:'Origem inválida.'},{status:403});
 await assert.rejects(()=>financeRequest('/api/records'),e=>!e.needsSignIn&&e.message==='Origem inválida.');
 globalThis.fetch=async()=>{throw new TypeError('Failed to fetch');};
 await assert.rejects(()=>financeRequest('/api/records'),/valores continuam no formulário/);
}finally{globalThis.fetch=originalFetch;}
assert(finance.isDayRecord({date:'2026-09-29',revenue:12000,investment:3000}));
assert(!finance.isDayRecord({date:'2026-02-30',revenue:12000,investment:3000}));
assert(!finance.isDayRecord({date:'2026-09-29',revenue:'12000',investment:3000}));
const rows=[{date:'2026-10-01',revenue:10000,investment:2000},{date:'2026-09-30',revenue:20000,investment:5000},{date:'2026-09-29',revenue:12000,investment:3000}];
const elements={Table:'table',TableHeader:'thead',TableBody:'tbody',TableRow:'tr',TableHead:'th',TableCell:'td'};
const hooks={...React,useState:init=>{const value=typeof init==='function'?init():init;return [Array.isArray(value)?rows:value===true?false:value,()=>{}];},useEffect:()=>{},useCallback:fn=>fn};
function mockRequire(name){
 if(name==='react')return hooks;
 if(name==='@/lib/finance')return {...finance,today:()=> '2026-10-01'};
 if(name==='@/lib/finance-client')return {financeRequest,FinanceApiError};
 if(name==='next/image'||name==='next/link'||name==='@/components/studio-brand')return {default:()=>null};
 if(name==='lucide-react')return new Proxy({}, {get:()=>()=>null});
 if(name==='sonner')return {Toaster:()=>null,toast:{success(){},error(){}}};
 if(name.startsWith('@/components/ui/'))return new Proxy({}, {get:(_target,key)=>props=>React.createElement(elements[key]||'div',null,props.children)});
 return require(name);
}
const context={exports:{},require:mockRequire};vm.runInNewContext(await compile('app/dashboard.tsx',ts.ModuleKind.CommonJS),context);
const html=renderToStaticMarkup(React.createElement(context.exports.default,{accountEmail:'test@example.test',signInPath:'/signin-with-chatgpt?return_to=%2F'}));
for(const day of ['29/09/2026','30/09/2026','01/10/2026'])assert(html.includes(day),`History must show ${day} while October is selected`);
assert(html.includes('Histórico completo'));assert(html.includes('Todos os meses'));
const summaryHtml=html.slice(html.indexOf('class="metrics"'),html.indexOf('class="marginline"'));
assert(summaryHtml.includes('100,00'));assert(summaryHtml.includes('20,00'));assert(summaryHtml.includes('80,00'));assert(!summaryHtml.includes('420,00'));
console.log('PASS: JSON responses, expired session, failed saves, all-month history and monthly totals.');

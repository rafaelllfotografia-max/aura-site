CREATE TABLE `daily_records` (
	`user_id` text NOT NULL,
	`date` text NOT NULL,
	`revenue_cents` integer NOT NULL,
	`investment_cents` integer NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `date`)
);

import {getChatGPTUser} from '../../chatgpt-auth';
import {getStorage} from '@/db';
import {validDate} from '@/lib/finance';
export const dynamic='force-dynamic';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){
 const user=await getChatGPTUser();if(!user)return json({error:'Entre com sua conta para consultar seus registros.'},401);
 try{const result=await getStorage().prepare('SELECT date, revenue_cents AS revenue, investment_cents AS investment FROM daily_records WHERE user_id = ? ORDER BY date DESC').bind(user.userId).all();return json({records:result.results});}catch(e){console.error('Load records',e);return json({error:'Não foi possível carregar seus registros. Tente novamente.'},503);}
}
export async function PUT(request:Request){
 const user=await getChatGPTUser();if(!user)return json({error:'Entre com sua conta para salvar.'},401);
 if(request.headers.get('origin')&&request.headers.get('origin')!==new URL(request.url).origin)return json({error:'Origem inválida.'},403);
 let body: {date:string;revenue:number;investment:number}|null;try{body=await request.json() as {date:string;revenue:number;investment:number}|null;}catch{return json({error:'Dados inválidos.'},400);}
 if(!body||!validDate(body.date)||!Number.isSafeInteger(body.revenue)||!Number.isSafeInteger(body.investment)||body.revenue<0||body.investment<0||body.revenue>100000000000||body.investment>100000000000)return json({error:'Confira a data e os valores informados.'},400);
 try{await getStorage().prepare('INSERT INTO daily_records (user_id,date,revenue_cents,investment_cents,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(user_id,date) DO UPDATE SET revenue_cents=excluded.revenue_cents,investment_cents=excluded.investment_cents,updated_at=excluded.updated_at').bind(user.userId,body.date,body.revenue,body.investment,new Date().toISOString()).run();return json({record:{date:body.date,revenue:body.revenue,investment:body.investment}});}catch(e){console.error('Save record',e);return json({error:'Não foi possível salvar. Seus valores continuam no formulário.'},503);}
}
export async function DELETE(request:Request){
 const user=await getChatGPTUser();if(!user)return json({error:'Entre com sua conta para excluir.'},401);
 if(request.headers.get('origin')&&request.headers.get('origin')!==new URL(request.url).origin)return json({error:'Origem inválida.'},403);
 const date=new URL(request.url).searchParams.get('date');if(!validDate(date))return json({error:'Data inválida.'},400);
 try{await getStorage().prepare('DELETE FROM daily_records WHERE user_id=? AND date=?').bind(user.userId,date).run();return json({ok:true});}catch(e){console.error('Delete record',e);return json({error:'Não foi possível excluir. Tente novamente.'},503);}
}

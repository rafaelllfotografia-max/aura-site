import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Meu Lucro — Aura Foto AI",
  description: "Registre seu faturamento e investimento e acompanhe o lucro de cada dia.",
  icons: {
    icon: "/aura-logo.jpg",
    shortcut: "/aura-logo.jpg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" className="dark">
      <body className="antialiased">{children}</body>
    </html>
  );
}

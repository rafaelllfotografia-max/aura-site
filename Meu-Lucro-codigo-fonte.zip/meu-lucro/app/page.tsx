import {chatGPTSignInPath,requireChatGPTUser} from './chatgpt-auth';
import Dashboard from './dashboard';
export const dynamic='force-dynamic';
export default async function Page(){const user=await requireChatGPTUser('/');return <Dashboard accountEmail={user.email} signInPath={chatGPTSignInPath('/')}/>;}

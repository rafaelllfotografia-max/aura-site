import {chatGPTSignInPath,chatGPTSignOutPath,getChatGPTUser} from '../chatgpt-auth';
import StudioBrand from '@/components/studio-brand';
import Link from 'next/link';

export const dynamic='force-dynamic';

export default async function SwitchAccountPage(){
 const user=await getChatGPTUser();
 return <><header className="topbar"><Link className="brandlink" href="/"><StudioBrand/></Link></header><main className="accountpage"><section className="panel accountpanel"><h1>Trocar conta</h1>{user?<><p>Você está usando <strong className="accountaddress">{user.email}</strong>.</p><p>Saia desta conta e entre com o outro login do ChatGPT que deseja usar.</p><a className="accountprimary" href={chatGPTSignOutPath('/trocar-conta')} target="_top">Sair da conta atual</a></>:<><p>Entre com a conta do ChatGPT que deseja usar no Meu Lucro.</p><a className="accountprimary" href={chatGPTSignInPath('/')} target="_top">Entrar com ChatGPT</a></>}<div className="accounthelp"><p>Se o ChatGPT entrar automaticamente com a conta anterior, abra este site em outro perfil do navegador ou saia da conta atual no ChatGPT antes de entrar novamente.</p><p>O site é privado. Outra conta precisa receber permissão de acesso. Os registros já salvos continuam na conta atual; eles não são transferidos ao trocar o login.</p></div>{user&&<Link className="accountback" href="/">Voltar ao meu controle</Link>}</section></main></>;
}

export type DayRecord={date:string;revenue:number;investment:number};
export function isDayRecord(value:unknown):value is DayRecord{
 if(!value||typeof value!=='object'||!('date' in value)||!('revenue' in value)||!('investment' in value))return false;
 return validDate(value.date)&&[value.revenue,value.investment].every(v=>typeof v==='number'&&Number.isSafeInteger(v)&&v>=0&&v<=100000000000);
}
export function parseMoney(raw:string):number{
 const s=raw.trim().replace(/^R\$\s*/, '');
 const normalized=s.includes(',')?s.replace(/\./g,'').replace(',','.'):s;
 if(!/^\d+(\.\d{1,2})?$/.test(normalized))throw new Error('Informe um valor válido com até 2 casas decimais.');
 const [whole,cents='']=normalized.split('.');
 const value=Number(whole)*100+Number(cents.padEnd(2,'0'));
 if(!Number.isSafeInteger(value)||value>100000000000)throw new Error('Valor acima do limite permitido.');
 return value;
}
export function validDate(value:unknown):value is string{
 if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value)||value<'2000-01-01'||value>'2100-12-31')return false;
 const d=new Date(value+'T12:00:00Z');return !Number.isNaN(d.getTime())&&d.toISOString().slice(0,10)===value;
}
export function totals(rows:DayRecord[]){const revenue=rows.reduce((s,r)=>s+r.revenue,0);const investment=rows.reduce((s,r)=>s+r.investment,0);return {revenue,investment,profit:revenue-investment,margin:revenue===0?null:(revenue-investment)/revenue};}
export function today(){return new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}

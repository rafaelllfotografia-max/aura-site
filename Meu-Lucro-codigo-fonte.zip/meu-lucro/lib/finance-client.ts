export class FinanceApiError extends Error {
  constructor(message:string,public needsSignIn=false){super(message);this.name='FinanceApiError';}
}

export async function financeRequest(path:string,init:RequestInit={}):Promise<unknown>{
 const headers=new Headers(init.headers);headers.set('Accept','application/json');
 let response:Response;
 try{response=await fetch(path,{...init,headers,credentials:'same-origin',cache:'no-store',redirect:'manual'});}
 catch{throw new FinanceApiError('Não foi possível conectar ao site. Tente novamente; seus valores continuam no formulário.');}
 if(response.type==='opaqueredirect'||(response.status>=300&&response.status<400))throw new FinanceApiError('Entre novamente para continuar. Seus valores ainda não foram confirmados.',true);
 const isJson=/\bapplication\/(?:[\w.-]+\+)?json\b/i.test(response.headers.get('content-type')??'');
 if(!isJson){
  if(response.ok||response.status===401||response.status===403)throw new FinanceApiError('Não foi possível confirmar sua sessão. Entre novamente e tente salvar.',true);
  throw new FinanceApiError('O site está temporariamente indisponível. Tente novamente; seus valores continuam no formulário.');
 }
 let data:unknown;try{data=await response.json();}catch{throw new FinanceApiError('O servidor retornou uma resposta incompleta. Tente novamente; seus valores continuam no formulário.');}
 if(!response.ok){
  const message=data&&typeof data==='object'&&'error' in data&&typeof data.error==='string'?data.error:'Não foi possível concluir a operação. Tente novamente.';
  throw new FinanceApiError(message,response.status===401);
 }
 return data;
}

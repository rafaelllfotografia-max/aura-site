import Image from 'next/image';

export default function StudioBrand(){
 return <div className="brand"><Image className="studiologo" src="/aura-logo.jpg" alt="Logo Aura Foto AI" width={76} height={76} unoptimized priority/><div className="brandcopy"><span>AURA FOTO AI</span><small>Meu Lucro</small></div></div>;
}

# Meu Lucro — código-fonte para download

Este arquivo contém o código atual do Meu Lucro, incluindo o tema escuro, a logo Aura Foto AI, o banner e as correções do histórico e do salvamento.

IMPORTANTE: este é o projeto original hospedado em Sites/ChatGPT. Ele ainda NÃO está adaptado para publicação direta na Vercel. Só importar este ZIP não fará o login e o banco de dados funcionarem.

## O que está incluído

- Interface, cálculos de faturamento, investimento, lucro e margem.
- Histórico de todos os meses e edição dos lançamentos.
- Código das rotas de leitura, salvamento e exclusão.
- Estrutura e migrações do banco, componentes e imagens.
- Configuração e dependências do projeto original.

O ZIP não contém os lançamentos financeiros salvos no banco online, sessões, senhas, chaves de API, dependências instaladas nem o histórico do Git. Baixar este arquivo não altera o site atual.

## Antes de publicar na Vercel

O projeto usa Vinext/Cloudflare Workers, um banco Cloudflare D1 e autenticação fornecida pela hospedagem Sites. Uma migração precisa tratar estes três pontos:

1. **Execução e build:** adaptar para Next.js na Vercel; usar os comandos de Next.js e atualizar a configuração, as dependências e o lockfile. Apenas selecionar “Next.js” no painel não converte o projeto.
2. **Login:** substituir a autenticação de Sites por um provedor de login que funcione fora do ChatGPT, incluindo entrada, saída e troca de conta. As rotas `/signin-with-chatgpt` e `/signout-with-chatgpt` são fornecidas pela hospedagem atual. Não confie em cabeçalhos enviados pelo navegador para identificar usuários.
3. **Banco:** substituir a conexão D1 por uma conexão compatível com a Vercel, criar a tabela no banco escolhido e adaptar as consultas. Preservar o vínculo entre cada lançamento e seu usuário, os valores em centavos, a unicidade por usuário/data e o histórico completo.

Arquivos principais para essa adaptação:

- `package.json`, `vite.config.ts`, `build/sites-worker.ts` e `scripts/run-framework.mjs`: build e execução atuais.
- `app/chatgpt-auth.ts`, `app/page.tsx`, `app/trocar-conta/page.tsx`: login atual.
- `db/index.ts`, `db/schema.ts`, `drizzle/` e `app/api/records/route.ts`: banco e consultas.
- `app/dashboard.tsx`, `lib/finance.ts`, `lib/finance-client.ts`: interface e comportamento financeiro a preservar.

O arquivo `.openai/hosting.json` identifica a hospedagem Sites e não configura a Vercel.

## Publicar depois da adaptação

1. Extraia este ZIP no computador.
2. Crie um repositório no GitHub e envie os arquivos da pasta `meu-lucro` — não envie o próprio ZIP. O `package.json` deve estar na raiz do projeto.
3. Entre em https://vercel.com e escolha “New Project”.
4. Conecte o GitHub e importe o repositório.
5. Escolha o preset Next.js da versão adaptada, confira a pasta raiz e os comandos de instalação/build.
6. Cadastre as variáveis de ambiente do novo banco e do novo login no painel da Vercel. Não coloque senhas no código nem em variáveis públicas.
7. Clique em “Deploy”.
8. Confira entrada, saída, troca de conta, criação, edição, exclusão e histórico de meses diferentes. Confirme também que uma conta não consegue ler os lançamentos de outra.

## Lançamentos já existentes

Os dados atuais continuam no banco do site original. Para levá-los à nova hospedagem é necessária uma exportação autorizada dos registros e uma importação no banco novo, associando as identidades antigas às novas. Este ZIP não realiza essa transferência.

## Documentação oficial

- Next.js na Vercel: https://vercel.com/docs/frameworks/full-stack/nextjs
- Importação de repositórios: https://vercel.com/docs/git

O README original do projeto está em `README-ORIGINAL.md`.
